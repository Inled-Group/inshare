// Licencia GNU-GPL v3.0
// Creado por Inled Group en 2025
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const os = require('os');

const app = express();
const PORT = 8080;

// Crear directorio de uploads si no existe
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir);
}

// Configurar multer para el manejo de archivos
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsDir);
  },
  filename: function (req, file, cb) {
    // Mantener el nombre original del archivo con timestamp para evitar conflictos
    const timestamp = Date.now();
    const originalName = Buffer.from(file.originalname, 'latin1').toString('utf8');
    cb(null, timestamp + '-' + originalName);
  }
});

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB límite
  }
});

// Middleware
app.use(express.static('public'));
app.use('/uploads', express.static(uploadsDir));

// Función para obtener la IP local
function getLocalIP() {
  const interfaces = os.networkInterfaces();
  for (let devName in interfaces) {
    const iface = interfaces[devName];
    for (let i = 0; i < iface.length; i++) {
      const alias = iface[i];
      if (alias.family === 'IPv4' && alias.address !== '127.0.0.1' && !alias.internal) {
        return alias.address;
      }
    }
  }
  return '127.0.0.1';
}

// Función para formatear el tamaño de archivo
function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Ruta principal - servir el HTML
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Ruta para obtener información de red
app.get('/api/network-info', (req, res) => {
  const localIP = getLocalIP();
  res.json({
    networkUrl: 'http://' + localIP + ':' + PORT
  });
});

// Ruta para subir archivos
app.post('/upload', upload.array('files'), (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ error: 'No se seleccionaron archivos' });
    }

    const uploadedFiles = req.files.map(file => {
      // Decodificar correctamente el nombre del archivo
      let originalName;
      try {
        originalName = Buffer.from(file.originalname, 'latin1').toString('utf8');
      } catch (e) {
        originalName = file.originalname;
      }
      
      return {
        originalName: originalName,
        filename: file.filename,
        size: formatFileSize(file.size)
      };
    });

    console.log('Archivos subidos:', uploadedFiles);
    res.json({ 
      success: true, 
      message: uploadedFiles.length + ' archivo(s) subido(s) correctamente',
      files: uploadedFiles 
    });
  } catch (error) {
    console.error('Error al subir archivos:', error);
    res.status(500).json({ error: 'Error al subir archivos' });
  }
});

// Ruta para listar archivos
app.get('/files', (req, res) => {
  try {
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir);
      return res.json([]);
    }

    const files = fs.readdirSync(uploadsDir)
      .filter(filename => {
        // Filtrar archivos ocultos y directorios
        return !filename.startsWith('.') && fs.statSync(path.join(uploadsDir, filename)).isFile();
      })
      .map(filename => {
        const filePath = path.join(uploadsDir, filename);
        const stats = fs.statSync(filePath);
        
        // Extraer nombre original del archivo
        let originalName = filename.replace(/^\d+-/, '');
        
        return {
          filename: filename,
          originalName: originalName,
          size: formatFileSize(stats.size),
          uploadDate: stats.mtime.toLocaleDateString('es-ES', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
          })
        };
      });

    // Ordenar por fecha de modificación (más reciente primero)
    files.sort((a, b) => {
      const aPath = path.join(uploadsDir, a.filename);
      const bPath = path.join(uploadsDir, b.filename);
      return fs.statSync(bPath).mtime - fs.statSync(aPath).mtime;
    });

    console.log('Archivos encontrados:', files.length);
    res.json(files);
  } catch (error) {
    console.error('Error al listar archivos:', error);
    res.status(500).json({ error: 'Error al listar archivos' });
  }
});

// Ruta para descargar archivos
app.get('/download/:filename', (req, res) => {
  try {
    const filename = decodeURIComponent(req.params.filename);
    const filePath = path.join(uploadsDir, filename);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'Archivo no encontrado' });
    }
    
    // Obtener nombre original para la descarga
    const originalName = filename.replace(/^\d+-/, '');
    
    res.download(filePath, originalName, (err) => {
      if (err) {
        console.error('Error al descargar archivo:', err);
        res.status(500).json({ error: 'Error al descargar archivo' });
      }
    });
  } catch (error) {
    res.status(500).json({ error: 'Error al procesar descarga' });
  }
});

// Ruta para eliminar archivos
app.delete('/delete/:filename', (req, res) => {
  try {
    const filename = decodeURIComponent(req.params.filename);
    const filePath = path.join(uploadsDir, filename);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'Archivo no encontrado' });
    }
    
    fs.unlinkSync(filePath);
    res.json({ success: true, message: 'Archivo eliminado correctamente' });
  } catch (error) {
    res.status(500).json({ error: 'Error al eliminar archivo' });
  }
});

// Iniciar servidor
app.listen(PORT, '0.0.0.0', () => {
  const localIP = getLocalIP();
  console.log(`
    *******
    *******
    *******
     ******
    =======   ========         =======  =======            ================  ==============
    =======   =========        =======  =======            ================  =================
    =======   ==========       =======  =======            ================  ===================
    =======   ===========      =======  =======            ======+           =======    =========
    =======   =============    =======  =======            ======+           =======      ========
    =======   ==============   =======  =======            ===============   =======       ========
    =======   ===============  =======  =======            ===============   =======       ========
    =======   =======  ======= =======  =======            ===============   =======       ========
    =======   =======   ==============  =======            ===============   =======       ========
    =======   =======    =============  =======            ======+           =======      ========
    =======   =======     ============  =======            ======+           =======    =========
    =======   =======      ===========  =================  ================  ===================
    =======   =======        =========  =================  ================  ==================
    =======   =======         ========  =================  ================  ===============
  `);
  console.log('We make a better world');
  console.log('🚀 Servidor de archivos iniciado correctamente');
  console.log('📡 Accesos disponibles:');
  console.log('   Local: http://localhost:' + PORT);
  console.log('   Red:   http://' + localIP + ':' + PORT);
   console.log('💡 Comparte la URL de red para que otros puedan acceder');
});
